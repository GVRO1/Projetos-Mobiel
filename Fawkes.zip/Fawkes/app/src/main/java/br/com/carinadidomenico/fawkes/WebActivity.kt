package br.com.carinadidomenico.fawkes

import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_web.*

class WebActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)

        wbweb.settings.javaScriptEnabled = true
        wbweb.loadUrl("http://br.cellep.com")

        wbweb.webViewClient = object : WebViewClient(){

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)

                Inpbusca.setText(url)
            }


        }



        btnVoltar.setOnClickListener {
            wbweb.goBack()
            //Handler().postDelayed({
            //    Inpbusca.setText(wbweb.url)
            //}, 1200)
        }
        btnAvançar.setOnClickListener {
            wbweb.goForward()
            //Handler().postDelayed({
            //    Inpbusca.setText(wbweb.url)
            //}, 1200)

        }

        btnRefresh.setOnClickListener {
            wbweb.reload()
        }

        btnPesquisar.setOnClickListener {
            var pesquisa = Inpbusca.text.toString().trim()

            if (Inpbusca.text.toString().trim().indexOf("www.") < 0) {
                pesquisa = "www.$pesquisa"
            }
            if (Inpbusca.text.toString().trim().indexOf("https://") < 0) {
                pesquisa = "https://$pesquisa"
            }
            if (Inpbusca.text.toString().trim().indexOf(".com") < 0) {
                pesquisa = "$pesquisa.com"
            }
            if (Inpbusca.text.toString().trim().isEmpty()) {
                Toast.makeText(this@WebActivity, "Campo vazio ", Toast.LENGTH_LONG).show()
            } else {
                wbweb.loadUrl(pesquisa)
                Inpbusca.setText(pesquisa)

            }


        }
    }
    }


