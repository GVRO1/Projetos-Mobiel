package br.com.renata.tela_login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Definindo o tempo da Splash
        Handler().postDelayed({
            // Criando a Intent
            startActivity(Intent(this@MainActivity,SplashActivity::class.java))

            finish()

        },3000)
    }
}


