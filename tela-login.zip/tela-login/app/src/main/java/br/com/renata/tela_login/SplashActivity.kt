package br.com.renata.tela_login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import kotlinx.android.synthetic.main.activity_splash.*

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Criando o clique do Botão Entrar
        btnEntrar.setOnClickListener {

            // Recuperando os dados
            val usuario = edtUsuario.text.toString().trim()
            val senha = edtSenha.text.toString().trim()

            //Condição para verificar se o usuario e senha estão conectados

            //Verificando se usuario esta vazio
            if (usuario.isEmpty()) {
                txvResultado.text = "Usúario vazio"
            }
            //Verificando se a senha esta vazio
            else if (senha.isEmpty()){
                txvResultado.text = "Senha vazia"
            }

            //Verificando se a senha é "gabriel"

            else if (usuario == "gabriel"){
                //Verificando se a senha é "123"

                if (senha == "123"){
                    txvResultado.text = "Senha correta"
                }

                else{
                    txvResultado.text = "Senha incorreta"
                }
            }

            //Se o usuario não for "gabriel"
            else {
                txvResultado.text = "Usúario incorreto"
            }

        }
    }
}

